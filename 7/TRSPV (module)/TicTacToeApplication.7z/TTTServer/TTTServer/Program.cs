﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Threading.Tasks;
using TTTServiceWCF;

namespace TTTServer
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost myServiceHost = new ServiceHost(typeof(TTTService), new Uri[] { });
            myServiceHost.AddServiceEndpoint(typeof(ITTTService), new WSHttpBinding(),
                                              "http://localhost:8000/TicTacToe/Game/");
            myServiceHost.Open();
            Console.WriteLine("wcf-служба доступена");
            Console.ReadLine();
            myServiceHost.Close();
        }
    }
}
