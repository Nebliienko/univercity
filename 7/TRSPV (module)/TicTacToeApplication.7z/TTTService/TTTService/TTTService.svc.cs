﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace TTTServiceWCF
{
    public class TTTService : ITTTService
    {
        public static int N = 3;
        public GameEntity Game { get; set; }

        public TTTService()
        {
            Game = new GameEntity();
        }

        public GameEntity activatePlayer(bool isSingle)
        {
            Game.Pole = new int[N][];
            for (int j = 0; j < N; j++)
            {
                Game.Pole[j] = new int[N];
            }
            Game.IsSinglePlayer = isSingle;
            Game.CurrentPlayer = new Random().Next(2);
            Game.IsWinner = false;
            Game.CurrentTurn = 0;
            checkForAITurn();
            return Game;
        }

        public GameEntity checkForAITurn()
        {
            if (Game.IsSinglePlayer && Game.CurrentPlayer == 1)
            {
                int x = new Random().Next(3);
                int y = new Random().Next(3);
                while (Game.Pole[x][y] != 0)
                {
                    x = new Random().Next(3);
                    y = new Random().Next(3);
                }
                Game.AiX = x;
                Game.AiY = y;
                doTurn(x, y);
            }
            return Game;
        }

        public GameEntity doTurn(int x, int y)
        {
            Game.CurrentTurn++;
            Game.Pole[x][y] = Game.CurrentPlayer + 1;
            if (checkForWinning())
            {
                Game.IsWinner = true;
            }
            if (Game.CurrentPlayer == 0)
                Game.CurrentPlayer = 1;
            else
                Game.CurrentPlayer = 0;
            return Game;
        }

        private bool checkForWinning()
        {
            int row = 0, column = 0, d1 = Game.Pole[0][0], d2 = Game.Pole[2][0];
            for (int i = 0; i < N; i++)
            {
                row = Game.Pole[i][0];
                column = Game.Pole[0][i];
                for (int j = 1; j < N; j++)
                {
                    if (row != Game.Pole[i][j])
                    {
                        row = 0;
                    }
                    if (column != Game.Pole[j][i])
                    {
                        column = 0;
                    }
                    if (d1 != Game.Pole[i][i])
                    {
                        d1 = 0;
                    }
                    if (d2 != Game.Pole[N - 1 - i][i])
                    {
                        d2 = 0;
                    }
                }
                if (row != 0 || column != 0)
                    return true;
            }
            return d1 != 0 || d2 != 0;
        }
    }
}
