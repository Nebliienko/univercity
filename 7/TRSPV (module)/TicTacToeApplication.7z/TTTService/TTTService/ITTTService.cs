﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace TTTServiceWCF
{
    [ServiceContract]
    public interface ITTTService
    {

        [OperationContract]
        GameEntity activatePlayer(bool isSingle);

        [OperationContract]
        GameEntity doTurn(int x, int y);

        [OperationContract]
        GameEntity checkForAITurn();

    }

    [DataContract]
    public class GameEntity
    {

        [DataMember]
        public int[][] Pole { get; set; }
        [DataMember]
        public bool IsWinner { get; set; }
        [DataMember]
        public bool IsSinglePlayer { get; set; }
        [DataMember]
        public int CurrentPlayer { get; set; }
        [DataMember]
        public int CurrentTurn { get; set; }
        [DataMember]
        public int AiX { get; set; }
        [DataMember]
        public int AiY { get; set; }

    }
}
