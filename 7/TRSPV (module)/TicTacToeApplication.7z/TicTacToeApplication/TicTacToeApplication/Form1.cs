﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TTTServiceWCF;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace TicTacToeApplication
{
    public partial class Form1 : Form
    {
        private ITTTService service;
        private int CurrentTurn = 0;
        public GameEntity Game { get; set; }

        public Form1()
        {
            InitializeComponent();
            ChannelFactory<ITTTService> factory = new ChannelFactory<ITTTService>(new WSHttpBinding());
            service = factory.CreateChannel(new EndpointAddress("http://localhost:8000/TicTacToe/Game/"));
        }

        private void singlePlayButton_Click(object sender, EventArgs e)
        {
            activateGame(true);
        }

        private void duoPlayButton_Click(object sender, EventArgs e)
        {
            activateGame(false);
        }

        private void activateGame(bool isSingle)
        {
            Game = service.activatePlayer(isSingle);
            MessageBox.Show("Game is started");
            tttGroup.Enabled = true;
            singlePlayButton.Enabled = false;
            duoPlayButton.Enabled = false;
            tipLabel.Text = getPlayer() + " turn";
            checkSinglePlayer();
        }

        private void pos00Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos00Button))
            {
                return;
            }
            buttonAssigned(pos00Button, 0, 0);
        }

        private void pos01Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos01Button))
            {
                return;
            }
            buttonAssigned(pos01Button, 0, 1);
        }

        private void pos02Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos02Button))
            {
                return;
            }
            buttonAssigned(pos02Button, 0, 2);
        }

        private void pos10Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos10Button))
            {
                return;
            }
            buttonAssigned(pos10Button, 1, 0);
        }

        private void pos11Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos11Button))
            {
                return;
            }
            buttonAssigned(pos11Button, 1, 1);
        }

        private void pos12Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos12Button))
            {
                return;
            }
            buttonAssigned(pos12Button, 1, 2);
        }

        private void pos20Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos20Button))
            {
                return;
            }
            buttonAssigned(pos20Button, 2, 0);
        }

        private void pos21Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos21Button))
            {
                return;
            }
            buttonAssigned(pos21Button, 2, 1);
        }

        private void pos22Button_Click(object sender, EventArgs e)
        {
            if (isClicked(pos22Button))
            {
                return;
            }
            buttonAssigned(pos22Button, 2, 2);
        }

        private void buttonAssigned(Button button, int x, int y)
        {
            changeBackground(button, Game.CurrentPlayer);
            Game = service.doTurn(x, y);
            checkForWin();
            checkSinglePlayer();
            checkForWin();
            tipLabel.Text = getPlayer() + " turn";
        }

        private void checkSinglePlayer()
        {
            if (Game.IsSinglePlayer)
            {
                Game = service.checkForAITurn();
                Button control = this.Controls.Find("pos" + Game.AiX + Game.AiY + "Button", true).FirstOrDefault() as Button;
                changeBackground(control, 1);
            }
        }

        private bool isClicked(Button button)
        {
            if (button.BackgroundImage != null)
            {
                tipLabel.Text = "You have been already pushed this";
            }
            return button.BackgroundImage != null;
        }

        private void checkForWin()
        {
            if (Game.IsWinner)
            {
                MessageBox.Show(getPlayerInverse() + " won");
                if (Game.CurrentPlayer == 0)
                {
                    player1Score.Text = "" + (int.Parse(player1Score.Text) + 1);
                }
                else
                {
                    player0Score.Text = "" + (int.Parse(player0Score.Text) + 1);
                }
                resetGame();
                return;
            }
            if (Game.CurrentTurn == 9)
            {
                MessageBox.Show("Draw!");
                resetGame();
            }
        }

        private string getPlayer()
        {
            return "Player " + (Game.CurrentPlayer == 0 ? "X" : "O");
        }
        private string getPlayerInverse()
        {
            return "Player " + (Game.CurrentPlayer == 1 ? "X" : "O");
        }

        private void resetGame()
        {
            pos00Button.BackgroundImage = null;
            pos01Button.BackgroundImage = null;
            pos02Button.BackgroundImage = null;
            pos10Button.BackgroundImage = null;
            pos11Button.BackgroundImage = null;
            pos12Button.BackgroundImage = null;
            pos20Button.BackgroundImage = null;
            pos21Button.BackgroundImage = null;
            pos22Button.BackgroundImage = null;
            Game = service.activatePlayer(Game.IsSinglePlayer);
            tipLabel.Text = getPlayer() + " turn";
        }

        private void changeBackground(Button button, int p)
        {
            button.BackgroundImage = p == 0 ? Image.FromFile("X.png") : Image.FromFile("O.png");
        }
    }
}
