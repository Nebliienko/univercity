﻿namespace TicTacToeApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tttGroup = new System.Windows.Forms.GroupBox();
            this.pos22Button = new System.Windows.Forms.Button();
            this.pos21Button = new System.Windows.Forms.Button();
            this.pos20Button = new System.Windows.Forms.Button();
            this.pos12Button = new System.Windows.Forms.Button();
            this.pos11Button = new System.Windows.Forms.Button();
            this.pos10Button = new System.Windows.Forms.Button();
            this.pos02Button = new System.Windows.Forms.Button();
            this.pos01Button = new System.Windows.Forms.Button();
            this.pos00Button = new System.Windows.Forms.Button();
            this.tipLabel = new System.Windows.Forms.Label();
            this.singlePlayButton = new System.Windows.Forms.Button();
            this.duoPlayButton = new System.Windows.Forms.Button();
            this.player0 = new System.Windows.Forms.Label();
            this.player1 = new System.Windows.Forms.Label();
            this.player0Score = new System.Windows.Forms.Label();
            this.player1Score = new System.Windows.Forms.Label();
            this.tttGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // tttGroup
            // 
            this.tttGroup.Controls.Add(this.player1Score);
            this.tttGroup.Controls.Add(this.player0Score);
            this.tttGroup.Controls.Add(this.player1);
            this.tttGroup.Controls.Add(this.player0);
            this.tttGroup.Controls.Add(this.pos22Button);
            this.tttGroup.Controls.Add(this.pos21Button);
            this.tttGroup.Controls.Add(this.pos20Button);
            this.tttGroup.Controls.Add(this.pos12Button);
            this.tttGroup.Controls.Add(this.pos11Button);
            this.tttGroup.Controls.Add(this.pos10Button);
            this.tttGroup.Controls.Add(this.pos02Button);
            this.tttGroup.Controls.Add(this.pos01Button);
            this.tttGroup.Controls.Add(this.pos00Button);
            this.tttGroup.Enabled = false;
            this.tttGroup.Location = new System.Drawing.Point(52, 75);
            this.tttGroup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tttGroup.Name = "tttGroup";
            this.tttGroup.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tttGroup.Size = new System.Drawing.Size(806, 625);
            this.tttGroup.TabIndex = 0;
            this.tttGroup.TabStop = false;
            this.tttGroup.Text = "TicTacToe";
            // 
            // pos22Button
            // 
            this.pos22Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos22Button.Location = new System.Drawing.Point(484, 397);
            this.pos22Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos22Button.Name = "pos22Button";
            this.pos22Button.Size = new System.Drawing.Size(150, 142);
            this.pos22Button.TabIndex = 8;
            this.pos22Button.Text = " ";
            this.pos22Button.UseVisualStyleBackColor = true;
            this.pos22Button.Click += new System.EventHandler(this.pos22Button_Click);
            // 
            // pos21Button
            // 
            this.pos21Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos21Button.Location = new System.Drawing.Point(326, 397);
            this.pos21Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos21Button.Name = "pos21Button";
            this.pos21Button.Size = new System.Drawing.Size(150, 142);
            this.pos21Button.TabIndex = 7;
            this.pos21Button.Text = " ";
            this.pos21Button.UseVisualStyleBackColor = true;
            this.pos21Button.Click += new System.EventHandler(this.pos21Button_Click);
            // 
            // pos20Button
            // 
            this.pos20Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos20Button.Location = new System.Drawing.Point(166, 397);
            this.pos20Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos20Button.Name = "pos20Button";
            this.pos20Button.Size = new System.Drawing.Size(150, 142);
            this.pos20Button.TabIndex = 6;
            this.pos20Button.Text = " ";
            this.pos20Button.UseVisualStyleBackColor = true;
            this.pos20Button.Click += new System.EventHandler(this.pos20Button_Click);
            // 
            // pos12Button
            // 
            this.pos12Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos12Button.Location = new System.Drawing.Point(484, 246);
            this.pos12Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos12Button.Name = "pos12Button";
            this.pos12Button.Size = new System.Drawing.Size(150, 142);
            this.pos12Button.TabIndex = 5;
            this.pos12Button.Text = " ";
            this.pos12Button.UseVisualStyleBackColor = true;
            this.pos12Button.Click += new System.EventHandler(this.pos12Button_Click);
            // 
            // pos11Button
            // 
            this.pos11Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos11Button.Location = new System.Drawing.Point(326, 246);
            this.pos11Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos11Button.Name = "pos11Button";
            this.pos11Button.Size = new System.Drawing.Size(150, 142);
            this.pos11Button.TabIndex = 4;
            this.pos11Button.Text = " ";
            this.pos11Button.UseVisualStyleBackColor = true;
            this.pos11Button.Click += new System.EventHandler(this.pos11Button_Click);
            // 
            // pos10Button
            // 
            this.pos10Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos10Button.Location = new System.Drawing.Point(166, 246);
            this.pos10Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos10Button.Name = "pos10Button";
            this.pos10Button.Size = new System.Drawing.Size(150, 142);
            this.pos10Button.TabIndex = 3;
            this.pos10Button.Text = " ";
            this.pos10Button.UseVisualStyleBackColor = true;
            this.pos10Button.Click += new System.EventHandler(this.pos10Button_Click);
            // 
            // pos02Button
            // 
            this.pos02Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos02Button.Location = new System.Drawing.Point(484, 95);
            this.pos02Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos02Button.Name = "pos02Button";
            this.pos02Button.Size = new System.Drawing.Size(150, 142);
            this.pos02Button.TabIndex = 2;
            this.pos02Button.Text = " ";
            this.pos02Button.UseVisualStyleBackColor = true;
            this.pos02Button.Click += new System.EventHandler(this.pos02Button_Click);
            // 
            // pos01Button
            // 
            this.pos01Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos01Button.Location = new System.Drawing.Point(326, 95);
            this.pos01Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos01Button.Name = "pos01Button";
            this.pos01Button.Size = new System.Drawing.Size(150, 142);
            this.pos01Button.TabIndex = 1;
            this.pos01Button.Text = " ";
            this.pos01Button.UseVisualStyleBackColor = true;
            this.pos01Button.Click += new System.EventHandler(this.pos01Button_Click);
            // 
            // pos00Button
            // 
            this.pos00Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pos00Button.Location = new System.Drawing.Point(166, 95);
            this.pos00Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pos00Button.Name = "pos00Button";
            this.pos00Button.Size = new System.Drawing.Size(150, 142);
            this.pos00Button.TabIndex = 0;
            this.pos00Button.Text = " ";
            this.pos00Button.UseVisualStyleBackColor = true;
            this.pos00Button.Click += new System.EventHandler(this.pos00Button_Click);
            // 
            // tipLabel
            // 
            this.tipLabel.AutoSize = true;
            this.tipLabel.Location = new System.Drawing.Point(54, 734);
            this.tipLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tipLabel.Name = "tipLabel";
            this.tipLabel.Size = new System.Drawing.Size(0, 20);
            this.tipLabel.TabIndex = 1;
            // 
            // singlePlayButton
            // 
            this.singlePlayButton.Location = new System.Drawing.Point(51, 2);
            this.singlePlayButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.singlePlayButton.Name = "singlePlayButton";
            this.singlePlayButton.Size = new System.Drawing.Size(381, 65);
            this.singlePlayButton.TabIndex = 2;
            this.singlePlayButton.Text = "Single";
            this.singlePlayButton.UseVisualStyleBackColor = true;
            this.singlePlayButton.Click += new System.EventHandler(this.singlePlayButton_Click);
            // 
            // duoPlayButton
            // 
            this.duoPlayButton.Location = new System.Drawing.Point(477, 2);
            this.duoPlayButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.duoPlayButton.Name = "duoPlayButton";
            this.duoPlayButton.Size = new System.Drawing.Size(381, 65);
            this.duoPlayButton.TabIndex = 3;
            this.duoPlayButton.Text = "Duo";
            this.duoPlayButton.UseVisualStyleBackColor = true;
            this.duoPlayButton.Click += new System.EventHandler(this.duoPlayButton_Click);
            // 
            // player0
            // 
            this.player0.AutoSize = true;
            this.player0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.player0.ForeColor = System.Drawing.Color.Red;
            this.player0.Location = new System.Drawing.Point(42, 38);
            this.player0.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.player0.Name = "player0";
            this.player0.Size = new System.Drawing.Size(26, 25);
            this.player0.TabIndex = 4;
            this.player0.Text = "X";
            // 
            // player1
            // 
            this.player1.AutoSize = true;
            this.player1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.player1.ForeColor = System.Drawing.Color.Blue;
            this.player1.Location = new System.Drawing.Point(711, 38);
            this.player1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(28, 25);
            this.player1.TabIndex = 9;
            this.player1.Text = "O";
            // 
            // player0Score
            // 
            this.player0Score.AutoSize = true;
            this.player0Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.player0Score.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player0Score.Location = new System.Drawing.Point(44, 79);
            this.player0Score.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.player0Score.Name = "player0Score";
            this.player0Score.Size = new System.Drawing.Size(24, 25);
            this.player0Score.TabIndex = 10;
            this.player0Score.Text = "0";
            // 
            // player1Score
            // 
            this.player1Score.AutoSize = true;
            this.player1Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.player1Score.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player1Score.Location = new System.Drawing.Point(715, 79);
            this.player1Score.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.player1Score.Name = "player1Score";
            this.player1Score.Size = new System.Drawing.Size(24, 25);
            this.player1Score.TabIndex = 11;
            this.player1Score.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 855);
            this.Controls.Add(this.duoPlayButton);
            this.Controls.Add(this.singlePlayButton);
            this.Controls.Add(this.tipLabel);
            this.Controls.Add(this.tttGroup);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tttGroup.ResumeLayout(false);
            this.tttGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox tttGroup;
        private System.Windows.Forms.Button pos22Button;
        private System.Windows.Forms.Button pos21Button;
        private System.Windows.Forms.Button pos20Button;
        private System.Windows.Forms.Button pos12Button;
        private System.Windows.Forms.Button pos11Button;
        private System.Windows.Forms.Button pos10Button;
        private System.Windows.Forms.Button pos02Button;
        private System.Windows.Forms.Button pos01Button;
        private System.Windows.Forms.Button pos00Button;
        private System.Windows.Forms.Label tipLabel;
        private System.Windows.Forms.Button singlePlayButton;
        private System.Windows.Forms.Button duoPlayButton;
        private System.Windows.Forms.Label player1Score;
        private System.Windows.Forms.Label player0Score;
        private System.Windows.Forms.Label player1;
        private System.Windows.Forms.Label player0;
    }
}

