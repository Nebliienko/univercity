﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace FilmSearch
{
    public class Film
    {
        public int Id { get; set; }
        public string Caption { get; set; }
        public int Year { get; set; }
        public string Country { get; set; }
        public Director Director { get; set; }
        public int Length { get; set; }
    }

    public class Director
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
    }

    public class ConnectionServise
    {
        private OleDbConnection _connection;

        public OleDbConnection Connection
        {
            get { return _connection; }
        }

        public void OpenConnection()
        {
            _connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=film_search.mdb;");
            _connection.Open();
        }

        public void CloseConnection()
        {
            _connection.Close();
        }
    }

    public class FilmDao
    {
        private ConnectionServise connectionService = new ConnectionServise();
        DirectorDao directorDao = new DirectorDao();

        public void InsertFilm(Film film)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("INSERT INTO film" +
            " VALUES('{0}','{1}','{2}','{3}','{4}','{5}')",
            film.Id, film.Caption, film.Year, film.Country, film.Director.Id, film.Length);
            if (directorDao.GetDirector(film.Director.Id) == null)
            {
                directorDao.InsertDirector(film.Director);
            }
            using (var cmd = new OleDbCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            connectionService.CloseConnection();
        }

        public void updateFilm(Film film)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("UPDATE film" +
                " SET caption='{1}', year='{2}', country='{3}', director='{4}', length='{5}'" +
                " WHERE id={0}",
            film.Id, film.Caption, film.Year, film.Country, film.Director.Id, film.Length);
            if (directorDao.GetDirector(film.Director.Id) == null)
            {
                directorDao.InsertDirector(film.Director);
            }
            using (var cmd = new OleDbCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            connectionService.CloseConnection();
        }

        public void DeleteFilm(int id)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("DELETE FROM film WHERE id={0}", id);
            using (var cmd = new OleDbCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            connectionService.CloseConnection();
        }

        public List<Film> GetFilms()
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            const string sql = "SELECT * FROM film";
            var command = new OleDbCommand(sql, connection);
            List<Film> films = new List<Film>();
            using (OleDbDataReader datareader = command.ExecuteReader())
            {
                while (datareader != null && datareader.Read())
                {
                    Film film = parseDatareader(datareader);
                    films.Add(film);
                }
            }
            connectionService.CloseConnection();
            return films;
        }

        public Film GetFilm(int id)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = "SELECT * FROM film WHERE id= " + id;
            var command = new OleDbCommand(sql, connection);
            Film film = null;
            using (OleDbDataReader datareader = command.ExecuteReader())
            {
                if (datareader != null && datareader.Read())
                {
                    film = parseDatareader(datareader);
                }
            }
            connectionService.CloseConnection();
            return film;
        }

        public Film parseDatareader(OleDbDataReader datareader)
        {
            Film film = new Film();
            film.Id = datareader.GetInt32(0);
            film.Caption = datareader.GetString(1);
            film.Year = datareader.GetInt32(2);
            film.Country = datareader.GetString(3);
            film.Director = directorDao.GetDirector(datareader.GetInt32(4));
            film.Length = datareader.GetInt32(5);
            return film;
        }
    }

    public class DirectorDao
    {
        private ConnectionServise connectionService = new ConnectionServise();

        public void InsertDirector(Director director)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("INSERT INTO director" +
            " VALUES('{0}','{1}','{2}')",
            director.Id, director.Name, director.Surname);
            using (var cmd = new OleDbCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            connectionService.CloseConnection();
        }

        public void UpdateDirector(Director director)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("UPDATE director" +
                " SET name='{1}', surname='{2}'" +
                " WHERE id={0}",
            director.Id, director.Name, director.Surname);
            using (var cmd = new OleDbCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            connectionService.CloseConnection();
        }

        public void DeleteDirector(int id)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("DELETE FROM director WHERE id={0}", id);
            using (var cmd = new OleDbCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            connectionService.CloseConnection();
        }

        public Director GetDirector(int id)
        {
            connectionService.OpenConnection();
            OleDbConnection connection = connectionService.Connection;
            string sql = string.Format("SELECT * FROM director WHERE id={0}", id);
            var command = new OleDbCommand(sql, connection);
            Director director = null;
            using (OleDbDataReader datareader = command.ExecuteReader())
            {
                if (datareader != null && datareader.Read())
                {
                    director = new Director();
                    director.Id = datareader.GetInt32(0);
                    director.Name = datareader.GetString(1);
                    director.Surname = datareader.GetString(2);
                }
            }
            connectionService.CloseConnection();
            return director;
        }
    }


    class Program
    {
        static void Main()
        {
            FilmDao dao = new FilmDao();
            Film film = new Film();
            Director director = new Director();
            director.Id = 1;
            director.Name = "Bennett";
            director.Surname = "Miller";
            film.Id = 2;
            film.Caption = "Foxcatcher";
            film.Country = "USA";
            film.Year = 2014;
            film.Director = director;
            film.Length = 134;

            dao.InsertFilm(film);

            List<Film> films = dao.GetFilms();


            foreach (Film f in films)
            {
                Console.WriteLine("id: {0}, caption: {1}, year: {2}, country: {3}, director: {4}, length: {5}",
                    f.Id,
                    f.Caption,
                    f.Country,
                    f.Year,
                    f.Director.Name + " " + f.Director.Surname,
                    f.Length);
            }

            dao.DeleteFilm(film.Id);

            Console.ReadLine();
        }
    }
}

