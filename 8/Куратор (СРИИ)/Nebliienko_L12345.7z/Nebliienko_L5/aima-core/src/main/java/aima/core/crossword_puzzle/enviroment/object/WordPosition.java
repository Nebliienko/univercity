package aima.core.crossword_puzzle.enviroment.object;

public enum WordPosition {

    VERTICAL, HORISONTAL;

}
