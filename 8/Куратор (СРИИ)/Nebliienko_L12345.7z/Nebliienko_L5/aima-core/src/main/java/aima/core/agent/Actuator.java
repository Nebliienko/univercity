package aima.core.agent;

public interface Actuator
{
	
}
