package aima.core.environment.xyenv;

import aima.core.agent.environments.EnvironmentObject;

/**
 * @author Ravi Mohan
 * 
 */
public class Wall implements EnvironmentObject {

}