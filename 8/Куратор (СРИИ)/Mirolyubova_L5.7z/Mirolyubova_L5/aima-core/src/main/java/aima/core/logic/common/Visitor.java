package aima.core.logic.common;

/**
 * @author Ravi Mohan
 * 
 */
public interface Visitor {

}