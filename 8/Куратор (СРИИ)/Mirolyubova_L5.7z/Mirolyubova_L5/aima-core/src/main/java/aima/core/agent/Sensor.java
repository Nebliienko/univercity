package aima.core.agent;

import aima.core.agent.percept.Percept;

public interface Sensor
{
	public Percept getPercept();
}
