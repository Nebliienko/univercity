package aima.core.probability.proposition;

/**
 * Indicator interface used to identify Sentence Propositions.
 * 
 * @author Ciaran O'Reilly
 */
public interface SentenceProposition extends Proposition {

}
