package aima.core.environment.crossword_puzzle;

public enum WordPosition {

    VERTICAL, HORISONTAL;

}
